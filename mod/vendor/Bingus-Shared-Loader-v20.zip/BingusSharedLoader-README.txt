Supports Steam build 25480438 / EXE 1.8.46015.0. Tested in game aboard the ship and in a mission.

v20: adds the LuaJIT churn guard, so code that keeps failing to compile is no
longer retried all session; the loader log shows a "LuaJIT churn:" line.
Since v19 the loader starts the game's shared LuaJIT code cache at 64 MB / 8,000
traces (growing to 256 MB / 16,000 after a flush), adds after_startup for mods,
and writes a fuller startup log; API 1 and addon discovery preserved. The loader
log shows a "LuaJIT cache:" line. Recommended for every CowboyBingus mod (they
need v18 or newer): replace the previous loader entry.

Includes the shared log folder for supported mods.

Logs: %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs



Bingus Shared Loader - v20



REQUIRED DEPENDENCY

Required by Armory Preview Cache, Know Your Constellation, Vanilla Plus Megapack or current Better Stratagem Bounce, Hellpod Steering Unlocked,

Reinforcement Beacons Fixed, Consistent Vaulting, Shallow Water Diving,

Sentry Aim Retention, Enemy Collision Synchronized, Vehicle Stability, and Controllable Hover Pack.

Install with Arsenal or HD2MM: import

Bingus-Shared-Loader-v20.zip, enable it alongside your chosen mods, then click Deploy.

One loader installation supports all your selected mods.



ARSENAL LOAD ORDER

Place Bingus Shared Loader LAST, at the bottom of the list, using Arsenal's

default priority setting. If you enabled first-mod priority, place it first

instead. Purge and Deploy after reordering.



Formerly named Shared Mod Loader.

Supported: Steam build 25480438 / EXE 1.8.46015.0.



1. Close Helldivers 2.

2. Remove or replace the previous Shared Mod Loader / Bingus Shared Loader entry

   in HDArsenal or HD2MM. Use only one manager.

3. Import Bingus-Shared-Loader-v20.zip and Vanilla-Plus-Megapack-v42.zip or your chosen

   current gameplay module ZIPs. Current standalone copies can remain

   installed alongside the megapack. give the pack winning priority over them.

4. Enable the loader and the gameplay mods, then Purge and Deploy.



The loader is a separate required download for current module-only Better

Stratagem Bounce, Hellpod Steering Unlocked, Reinforcement Beacons Fixed,

Consistent Vaulting, Shallow Water Diving, Sentry Aim Retention, and

Enemy Collision Synchronized, Vehicle Stability, and Controllable Hover Pack.

It has no gameplay effect alone. Enable the gameplay mods you want to use.



The manager GUID and internal API marker are unchanged.

Do not deploy old and renamed copies together. Remove older gameplay packages

that bundled their own startup loader before using current module-only packages.



Check %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/BingusSharedLoader.log for each installed module's status.

A module loading successfully does not prove its gameplay behavior.



HUD Ballistic Trajectory Overlay v2 (September 11, 2026):

Install the original overlay separately. Give Bingus Shared Loader the winning

priority over the overlay, then Purge and Deploy. Arsenal's shared-file warning

is expected for this supported pair. No extra compatibility package is needed.

The overlay is optional and works without the CowboyBingus gameplay mods.

To customize it, put its original HUDBTO.ini beside the game's bin and data

folders. Without that optional file, the overlay uses its own defaults.

The log should show mods/codex/gun_calibration: loaded when it is installed.



The loader preserves Wwise callbacks and does not replace boot. HUD+ 0.1.3

retains its own startup. Other startup replacements can still conflict.

The maintainer confirmed v3 works in-game with Overlay v2.

Loader-v7 adds Vanilla Plus Megapack and retains every separate module.

API 1 and the manager GUID remain unchanged. The megapack log entry is

mods/cowboybingus/vanilla_plus_megapack. its gameplay entries follow.

This release has passed offline startup and callback checks.



Keep this loader enabled while any dependent gameplay mod is enabled.

To remove it, first disable dependent mods, then disable the loader and Purge/Deploy.



Developed with assistance from GPT-6 Astra and Claude Opus 5.5.



Loader-v9 supports Enemy Collision Synchronized alone or inside the Megapack.

Its legacy module identity is retained for compatible upgrades.



Loader-v11 discovers mods/cowboybingus/hover_pack_cancel. Controllable Hover Pack v1 is a separate optional installation, confirmed working in-game.



Loader v12 adds optional discovery for Know Your Constellation.

Players without Know Your Constellation receive no new panel or gameplay changes.



Loader v13 registered Armory Preview Cache as an optional module using API 1.

Loader v14 adds the shared folder for all updated CowboyBingus mod logs.

Logs: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs
Requires Bingus Shared Loader v14 or newer for this log folder.
